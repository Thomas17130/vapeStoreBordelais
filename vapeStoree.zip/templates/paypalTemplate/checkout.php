<form action="../../src/Controller/paypal/payment.php" method="post">
    <input type="text" name="item" placeholder="Enter Item Name">
    <input type="text" name="amount" placeholder="Enter Amount">
    <input type="submit" name="submit" value="Pay">
</form>